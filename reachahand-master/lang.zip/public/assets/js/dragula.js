$(function() {
	'use strict'
	dragula([document.getElementById(left), document.getElementById(right)]);
	
});