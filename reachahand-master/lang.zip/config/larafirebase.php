<?php

return [

    'authentication_key' => env('FCM_SERVER_KEY')
];
